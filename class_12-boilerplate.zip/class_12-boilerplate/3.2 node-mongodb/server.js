const http = require("http");
const fs = require('fs');

// connect
// note: remember to whitelist your IP in network/accessList settings first
const { MongoClient, ServerApiVersion } = require('mongodb');

const uri = "mongodb+srv://kunal:NX7Hv7YNXD8ZiOqV@parsons.rv7ow9n.mongodb.net/?appName=Parsons";

// const uri = "mongodb+srv://kunal:NX7Hv7YNXD8ZiOqV@parsons.rv7ow9n.mongodb.net/?retryWrites=true&w=majority&appName=Parsons";
// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

// run task
async function run() {
  try {
    // Connect the client to the server (optional starting in v4.7)
    await client.connect();

    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");

    // list records
    const db1 = client.db('sample_mflix');
    const collection1 = db1.collection('users');
    console.log("Listing users:");
    console.log( await collection1.find().toArray() );

    // create new DB
    const db2 = client.db('school');
    const collection2 = db2.collection('students');

    // insert record
    const studentDocument = {
           name: 'Sarah1 Connors',
           birthdate: new Date(2025, 8, 29),
           address: { street: 'Pike Lane', city: 'Los Angeles', state: 'CA' },
    };

    await collection2.insertOne(studentDocument);
    console.log("Student added!");

  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}

run().catch(console.dir);

