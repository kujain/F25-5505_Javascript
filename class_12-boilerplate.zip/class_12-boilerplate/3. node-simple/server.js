const http = require("http");

const hostname = "127.0.0.1";
const port = 8000;

// Create HTTP server
const server = http.createServer((req, res) => {
   // Set the response HTTP header with HTTP status and Content type
   res.writeHead(200, {'Content-Type': 'text/html'});

   const url = req.url;

   // Send the response body
   if (url === '/') {
        res.write('<html>');
        res.write('<head><title>Enter</title></head>')
        res.write('<body><h1>ENTER YOUR NAME HERE.</h1><form action="/message" method="POST"><input type="text" name="message"><button type="submit">Send</button></form></body>')
        res.write('</html>');
        return res.end();
   }

   if (url === '/message') {
        res.write('<html>');
        res.write('<head><title>Done</title></head>')
        res.write('<body><h1>THANKS FOR VISITING.</h1><br><p>YOUR MESSAGE WILL ARRIVE SHORTLY.</p></body>')
        res.write('</html');
        return res.end();
   }

   res.end('<h1>Hello Class</h1> \n');
});

// Logs once the server starts listening
server.listen(port, hostname, () => {
   console.log(`NODE Server running at http://${hostname}:${port}/`);
})


