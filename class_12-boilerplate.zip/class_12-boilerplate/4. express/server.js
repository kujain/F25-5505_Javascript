var express = require('express');
var app = express();

// routing
app.get('/', function(req, res) {
  res.send('Hello Class!');
});

app.get('/users', function(req, res) {
  res.send('Hello User!');
});

app.get('/projects', function(req, res) {
  res.send('Hello Projects!');
});

app.listen(8002, function() {
  console.log('Example app listening on port 8002!');
});
